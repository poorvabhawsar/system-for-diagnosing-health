package Parser;

import gov.nih.nlm.nls.metamap.MetaMapApi;
import gov.nih.nlm.nls.metamap.MetaMapApiImpl;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import Indexer.WebMDIndex;

public class WebMDParser {

	static MetaMapApi api =null;
	//String serverhost =null;
	//int serverport,timeout;
	static List<String> theOptions=null;
	
	public static void connectToMetaServer()
	{
		api= new MetaMapApiImpl();
		String serverhost = MetaMapApi.DEFAULT_SERVER_HOST; 
		//  int serverport = MetaMapApi.DEFAULT_SERVER_PORT; 	// default port
		
		//String serverhost = "10.3.3.194";
		//String serverhost ="10.1.33.125";
		//String serverhost ="10.1.132.106";
		int serverport=8066;
	    int timeout = 0;
	    
	    api.setHost(serverhost);
	    api.setPort(serverport);
	    api.setTimeout(timeout);
	    
	    theOptions = new ArrayList<String>();
		
	}
	
	public static void main(String[] args) {

		WebMDIndex mi=null;
	//connect to MetaMap server
	    connectToMetaServer();
	    
	    
	 // add options in theOptions list
	    theOptions.add("-y");  // turn on Word Sense Disambiguation
	  //  theOptions.add("-K");
	  //  theOptions.add("-prune 5");
	    theOptions.add("-A");
	    theOptions.add("-u");
	    
	 // set options in metamap api object
	    WebMDIndex.setMetaMapOptions(theOptions,api);
		
		// FILE_PATH has the path to the folder of crawled data
		String FILES_PATH=args[0];
		File folder = new File(FILES_PATH);
		StringBuilder content=new StringBuilder();
		String disease=null;
		int filecount=1,numofindex=0;
		// pick files from folder extract text and send to the  parser
		//works well for mayoclinic
		
			for(File filetobeparsed:folder.listFiles())
			{
				try{
					content.setLength(0);
					mi=new WebMDIndex();
					Document doc = Jsoup.parse(filetobeparsed, "UTF-8");
				
					//get disease and content
					disease=mi.getDisease(doc.select("title").text(),api);	// customize
					content.append(doc.select("#textArea").text());

					//System.out.println("Content: "+content.toString()+"----END----");
					if(disease!=null && content.length()>0)
						mi.process(disease,content.toString(), api);
									
					System.out.println(filecount);
					filecount++;
					
					if(filecount%50==0)
					{
						createIndexFiles(numofindex);
						numofindex++;
					}
				}catch(Exception e)
				{
					System.out.println("Error while parsing "+e.toString());
				}	
			}
			if(filecount%50>0)
			{
				createIndexFiles(numofindex);
				numofindex++;
			}		
	}
	
	public static void createIndexFiles(int mark)
	{
		try{

			StringBuilder line=new StringBuilder();
			
			File symIndexFile=new File("Index2/webmdSymptomIndex"+mark);
			symIndexFile.createNewFile();
			PrintWriter indwriter=new PrintWriter(symIndexFile);
			
			File bodyIndexFile=new File("Index2/WebmdBodyIndex"+mark);
			bodyIndexFile.createNewFile();
			
			for(String sym:WebMDIndex.symIndex.keySet())
			{
				line.setLength(0);
				line.append(sym+"@");
				for(String dis:WebMDIndex.symIndex.get(sym))
					line.append(dis+",");
				line.append("\n");
				
				indwriter.write(line.toString());
			}
			indwriter.close();
			
			indwriter=new PrintWriter(bodyIndexFile);
			for(String bdy:WebMDIndex.bodyIndex.keySet())
			{
				line.setLength(0);
				line.append(bdy+"@");
				for(String dis:WebMDIndex.bodyIndex.get(bdy))
					line.append(dis+",");
				line.append("\n");
				
				indwriter.write(line.toString());
			}
			indwriter.close();
			
			
		
			// COncept name to Preferred name file
			File conpreFile=new File("Index2/WebmdconToPrefer"+mark);
			conpreFile.createNewFile();
			indwriter=new PrintWriter(conpreFile);
			
			for(String con:WebMDIndex.conceptToPrefer.keySet())
				indwriter.write(con+"@"+WebMDIndex.conceptToPrefer.get(con)+"\n");

			indwriter.close();
			
			// diseaseIndex Creation
			File diseaseIndexFile=new File("Index2/WebmddiseaseIndex"+mark);
			diseaseIndexFile.createNewFile();
			indwriter=new PrintWriter(diseaseIndexFile);
			
			for(String dis:WebMDIndex.diseaseIndex.keySet())
				indwriter.write(dis+"@"+WebMDIndex.diseaseIndex.get(dis)+"\n");

			indwriter.close();
			
			WebMDIndex.symIndex.clear();
			WebMDIndex.diseaseIndex.clear();
			WebMDIndex.bodyIndex.clear();
			WebMDIndex.conceptToPrefer.clear();
			
		
		}catch(Exception e)
		{
			System.out.println("Error in writing index "+e.toString());
		}
	}

}
